package com.xiaoxu.user.dao;

import org.durcframework.core.dao.BaseDao;
import com.xiaoxu.user.entity.BackUser;

public interface BackUserDao extends BaseDao<BackUser> {
}