package com.xiaoxu.user.entity;

/**
  
*/
public class BackUser {
	// 用户名
	private String username;
	// 密码
	private String password;
	// 添加时间
	private Date addTime;

	public void setUsername(String username){
		this.username = username;
	}

	public String getUsername(){
		return this.username;
	}

	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return this.password;
	}

	public void setAddTime(Date addTime){
		this.addTime = addTime;
	}

	public Date getAddTime(){
		return this.addTime;
	}

}