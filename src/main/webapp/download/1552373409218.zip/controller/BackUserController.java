package com.xiaoxu.user.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import com.xiaoxu.user.entity.BackUser;
import com.xiaoxu.user.entity.BackUserSch;
import com.xiaoxu.user.service.BackUserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class BackUserController extends
		CrudController<BackUser, BackUserService> {

	@RequestMapping("/addBackUser.do")
	public ModelAndView addBackUser(BackUser entity) {
		return this.add(entity);
	}

	@RequestMapping("/listBackUser.do")
	public ModelAndView listBackUser(BackUserSch searchEntity) {
		return this.list(searchEntity);
	}

	@RequestMapping("/updateBackUser.do")
	public ModelAndView updateBackUser(BackUser entity) {
		return this.modify(entity);
	}

	@RequestMapping("/delBackUser.do")
	public ModelAndView delBackUser(BackUser entity) {
		return this.remove(entity);
	}
	
}