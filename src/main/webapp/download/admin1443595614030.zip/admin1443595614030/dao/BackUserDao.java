package com.aaa.bbb.dao;

import org.durcframework.core.dao.BaseDao;
import com.aaa.bbb.entity.BackUser;

public interface BackUserDao extends BaseDao<BackUser> {
}