package com.aaa.bbb.service;

import org.durcframework.core.service.CrudService;
import com.aaa.bbb.dao.BackUserDao;
import com.aaa.bbb.entity.BackUser;
import org.springframework.stereotype.Service;

@Service
public class BackUserService extends CrudService<BackUser, BackUserDao> {

}